%% 
[pred_1, y_test_1] = cifar10_starter(); 
[pred_2, y_test_2] = cifar10_mod();  
%% 
[pred_3, y_test_3] = cifar10_mod();  
%% 
figure(1) 
set(gcf, 'Position', [10 10 900 600]);
%figure('Position', [10 10 900 600]);
