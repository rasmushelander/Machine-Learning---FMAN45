function y = relu_forward(x)
    y = max(x, 0); 
end
